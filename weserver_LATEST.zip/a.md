# 这是一级标题
## 这是二级标题
### 这是三级标题
#### 这是四级标题
##### 这是五级标题
###### 这是六级标题

**这是加粗的文字**

*这是倾斜的文字*`

***这是斜体加粗的文字***

~~这是加删除线的文字~~
>这是引用的内容

>>这是引用的内容

>>>>>>>>>>这是引用的内容
---

----

***

*****
![blockchain](https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=702257389,1274025419&fm=27&gp=0.jpg"区块链")
[简书](http://jianshu.com)

[百度](http://baidu.com)

I get 10 times more traffic from [Google][] than from [Yahoo][] or [MSN][].

  [google]: http://google.com/        "Google"
  [yahoo]:  http://search.yahoo.com/  "Yahoo Search"
  [msn]:    http://search.msn.com/    "MSN Search"

1.列表内容

2.列表内容

3.列表内容


    表头|表头|表头

    ---|:--:|---:

    内容|内容|内容

    内容|内容|内容
    
    
```

  代码...

  代码...

  代码...

```    

```

functionfun(){

    echo"这是一句非常牛逼的代码";    

}  

fun();

```


```flow

st=>start: 开始

op=>operation: My Operation

cond=>condition: Yes or No?

e=>end

st->op->cond

cond(yes)->e

cond(no)->op

&```








